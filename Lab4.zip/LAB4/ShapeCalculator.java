
public class ShapeCalculator {

    double area(double radius) {
        return 3.14 * radius * radius;
    }

    int area(int length, int breadth) {
        return length * breadth;
    }

    double area(double base, double height) {
        return 0.5 * base * height;
    }

    public static void main(String[] args) {
        ShapeCalculator obj = new ShapeCalculator();

        System.out.println("Area of Circle: " + obj.area(5.0));
        System.out.println("Area of Rectangle: " + obj.area(4, 6));
        System.out.println("Area of Triangle: " + obj.area(5.0, 4.0));
    }
}
