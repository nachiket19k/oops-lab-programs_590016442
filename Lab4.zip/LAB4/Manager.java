
class Employee {
    void work() {
        System.out.println("Employee works in company");
    }
}

public class Manager extends Employee {

    void work() {
        System.out.println("Manager manages the team");
    }

    public static void main(String[] args) {
        Employee obj = new Manager();
        obj.work();
    }
}
