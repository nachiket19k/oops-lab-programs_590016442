class ObjectVariable {
    int x = 10;

    public static void main(String[] args) {
        ObjectVariable obj = new ObjectVariable();
        System.out.println(obj.x);
    }
}