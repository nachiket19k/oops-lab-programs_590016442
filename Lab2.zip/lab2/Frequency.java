class Frequency {
    public static void main(String[] args) {
        int[] arr = {1,2,3,2,4,2};
        int key = 2;
        int count = 0;

        for (int i : arr) {
            if (i == key) count++;
        }

        System.out.println(count);
    }
}