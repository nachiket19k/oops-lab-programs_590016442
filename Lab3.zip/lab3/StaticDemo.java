class StaticDemo {
    static int a = 10;
    int b = 20;

    public static void main(String[] args) {
        System.out.println(a);
        StaticDemo obj = new StaticDemo();
        System.out.println(obj.b);
    }
}